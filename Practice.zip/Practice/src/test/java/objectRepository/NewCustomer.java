package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewCustomer {
	WebDriver driver;
	public NewCustomer(WebDriver driver)                                   
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}
	
	@FindBy(className="login")
	@CacheLookup 
    WebElement loginnew;
	
	@FindBy(id="email_create")
	@CacheLookup 
    WebElement email;
	
	@FindBy(id="SubmitCreate")
	@CacheLookup 
    WebElement submit;
	
	@FindBy(id="id_gender1")
	@CacheLookup 
    WebElement female;
	
	@FindBy(id="customer_firstname")
	@CacheLookup 
    WebElement fname;
	
	@FindBy(id="customer_lastname")
	@CacheLookup 
    WebElement lname;
	
	@FindBy(id="passwd")
	@CacheLookup 
    WebElement pwd;
	

	@FindBy(id="days")
	@CacheLookup 
    WebElement day;
	
	@FindBy(id="months")
	@CacheLookup 
    WebElement month;
	
	@FindBy(id="years")
	@CacheLookup 
    WebElement year;
	
	@FindBy(id="company")
	@CacheLookup 
    WebElement company;
	
	@FindBy(id="address1")
	@CacheLookup 
    WebElement address;
	
	@FindBy(id="address2")
	@CacheLookup 
    WebElement address2;
	
	@FindBy(id="city")
	@CacheLookup 
    WebElement city;
	
	@FindBy(id="id_state")
	@CacheLookup 
    WebElement state;
	
	@FindBy(id="postcode")
	@CacheLookup 
    WebElement code;
	
	@FindBy(id="id_country")
	@CacheLookup 
    WebElement country;
	
	@FindBy(id="other")
	@CacheLookup 
    WebElement other;
	
	@FindBy(id="phone")
	@CacheLookup 
    WebElement phone;
	
	@FindBy(id="phone_mobile")
	@CacheLookup 
    WebElement mobile;
	
	@FindBy(id="alias")
	@CacheLookup 
    WebElement alias;
	
	@FindBy(id="submitAccount")
	@CacheLookup 
    WebElement registerbtn;
	
	public WebElement LoginNew()
	{
		return loginnew;
	}
	
	
	public WebElement Registerbtn() {
		return registerbtn;
	}

	
	public WebElement Day() {
		return day;
	}

	public WebElement Month() {
		return month;
	}

	public WebElement Year() {
		return year;
	}

	public WebElement Company() {
		return company;
	}

	public WebElement Address() {
		return address;
	}
	
	
	public WebElement Fname() {
		return fname;
	}

	public WebElement Lname() {
		return lname;
	}

	public WebElement Pwd() {
		return pwd;
	}

	public WebElement Email() {
		return email;
	}

	public WebElement Submit() {
		return submit;
	}

	public WebElement Female() {
		
		return female;
	}

	public WebElement Address2() {
		return address2;
	}

	public WebElement City() {
		return city;
	}

	public WebElement State() {
		return state;
	}

	public WebElement Code() {
		return code;
	}

	public WebElement Country() {
		return country;
	}

	public WebElement Other() {
		return other;
	}

	public WebElement Phone() {
		return phone;
	}

	public WebElement Mobile() {
		return mobile;
	}

	public WebElement Alias() {
		return alias;
	}


	

	
}