package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ExixtingCustomer 
{
	WebDriver driver;
	public ExixtingCustomer(WebDriver driver)                                   
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}
	
	@FindBy(className="login")
	@CacheLookup 
    WebElement loginexi;
	
	@FindBy(name="email")
	@CacheLookup 
    WebElement emailexi;
	
	@FindBy(name="passwd")
	@CacheLookup 
    WebElement passwordexi;
	
	@FindBy(id="SubmitLogin")
	@CacheLookup 
    WebElement submit;
	
	@FindBy(xpath=".//*[@id='center_column']/ul/li/a/span")
	@CacheLookup 
    WebElement backbutton;
	
	@FindBy(className="sf-with-ul")
	@CacheLookup 
    WebElement womenbutton;

	@FindBy(xpath=".//*[@id='center_column']/ul/li[1]/div/div[2]/h5/a")
	@CacheLookup 
    WebElement fadeddress;
	
	@FindBy(name="Submit")
	@CacheLookup 
    WebElement addtocart;
	
	@FindBy(xpath=".//*[@id='layer_cart']/div[1]/div[2]/div[4]/a/span/i")
	@CacheLookup 
    WebElement chechout;
	
	@FindBy(xpath=".//*[@id='center_column']/p[2]/a[1]/span")
	@CacheLookup 
    WebElement chechoutsummary;
	
	@FindBy(name="processAddress")
	@CacheLookup 
    WebElement checkoutaddress;
	
	@FindBy(id="cgv")
	@CacheLookup 
    WebElement checkbox;
	
	@FindBy(name="processCarrier")
	@CacheLookup 
    WebElement checkoutcarrier;
	
	@FindBy(className="cheque")
	@CacheLookup 
    WebElement paycheck;
	
	@FindBy(xpath=".//*[@id='cart_navigation']/button")
	@CacheLookup 
    WebElement confirmorder;
	
	@FindBy(className="icon-home")
	@CacheLookup 
    WebElement backtohome;
	
	/*@FindBy(className="logout")
	@CacheLookup 
    WebElement signout;*/
	
	
	public WebElement LoginExi()
	{
		return loginexi;
	}
	public WebElement EmailExi()
	{
		return emailexi;
	}
	public WebElement PasswordExi()
	{
		return passwordexi;
	}
	public WebElement SubmitExi()
	{
		return submit;
	}
	public WebElement BackButton()
	{
		return backbutton;
	}
	public WebElement WomenButton()
	{
		return womenbutton;
	}
	public WebElement FadedDress()
	{
		return fadeddress;
	}
	public WebElement AddToCart()
	{
		return addtocart;
	}
	public WebElement ChechOut()
	{
		return chechout;
	}
	public WebElement CheckOutSummary()
	{
		return chechoutsummary;
	}
	public WebElement CheckOutAddress()
	{
		return checkoutaddress;
	}
	public WebElement CheckBox()
	{
		return checkbox;
	}
	public WebElement CheckOutCarrier()
	{
		return checkoutcarrier;
	}
	public WebElement PayCheck()
	{
		return paycheck;
	}
	public WebElement ConfirmOrder()
	{
		return confirmorder;
	}
	public WebElement BackToHome()
	{
		return backtohome;
	}
	
	
	/*public WebElement SignOut()
	{
		return signout;  
	}*/
}
