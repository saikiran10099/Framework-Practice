package stepDefinition;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import objectRepository.Alerts;
import objectRepository.ExixtingCustomer;
import objectRepository.NewCustomer;
import objectRepository.RetrivePwd;

public class LogoSteps {
	WebDriver driver;
	ExixtingCustomer exi;
	RetrivePwd retpwd;
	NewCustomer reg;
	Alerts al;
	//******************************************before method**********************************************//
	@Before
    public void before() 
    {
		 WebDriver driver = new FirefoxDriver();//(it is run time polymorphism)
		 driver.get("http://automationpractice.com/index.php");
		    driver.manage().window().maximize();
		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		    exi = new ExixtingCustomer(driver);
		    retpwd = new RetrivePwd(driver);
		    reg = new NewCustomer(driver);
		    al = new Alerts(driver);
    }
	//***************************************Existing user********************************************************//
	 @Given("^Enter url in browser$")
	    public void enter_url_in_browser() throws Throwable {
		
		    
	    }
	 @And("^click on sign in$")
	    public void click_on_sign_in() throws Throwable {
	        exi.LoginExi().click();
	    }
	    @When("^user enter vaild email address$")
	    public void user_enter_vaild_email_address() throws Throwable {
	        exi.EmailExi().sendKeys("sai@gmail.com");                                  // log.UserName().sendKeys("vrl");
	    }


	    /*@Then("^My Account page should be displayed and user has to click back button$")
	    public void my_account_page_should_be_displayed_and_user_has_to_click_back_button() throws Throwable 
	    {
	        exi.BackButton().click();
	    }*/
	    @And("^click on submit$")
	    public void click_on_submit() throws Throwable  {
	       exi.SubmitExi().click();
	       Thread.sleep(1000);
	    }

	    @And("^enter valid password$")
	    public void enter_valid_password() throws Throwable {
	       exi.PasswordExi().sendKeys("swa1234");
	    }

	    /*@Then("^item should add to cart$")
	    public void item_should_add_to_cart() throws Throwable {
	       
	    }*/

	    @And("^user has to click back button$")
	    public void user_has_to_click_back_button() throws Throwable {
	    	exi.BackButton().click();
	    }

	    @And("^click on women$")
	    public void click_on_women() throws Throwable {
	    	exi.WomenButton().click();
	    }

	    @And("^click on faded dress$")
	    public void click_on_faded_dress() throws Throwable {
	    	exi.FadedDress().click();
	    }

	    @And("^click on add to cart$")
	    public void click_on_add_to_cart() throws Throwable {
	       exi.AddToCart().click();
	    }


	    @And("^click on proceed to checkout$")
	    public void click_on_proceed_to_checkout() throws Throwable {
	    	exi.ChechOut().click();
	    }

	    @And("^click on proceed to check out in summary$")
	    public void click_on_proceed_to_check_out_in_summary() throws Throwable {
	    	exi.CheckOutSummary().click();
	    }

	    @And("^click on checkout in address$")
	    public void click_on_checkout_in_address() throws Throwable {
	    	exi.CheckOutAddress().click();
	    }

	    @And("^click on checkbox$")
	    public void click_on_checkbox() throws Throwable {
	    	exi.CheckBox().click();
	    }

	    @And("^click on checkout carrier$")
	    public void click_on_checkout_carrier() throws Throwable {
	    	exi.CheckOutCarrier().click();
	    }

	    @And("^click on pay check$")
	    public void click_on_pay_check() throws Throwable {
	    	exi.PayCheck().click();
	    }

	    @And("^click on confirm oder$")
	    public void click_on_confirm_oder() throws Throwable {
	    	exi.ConfirmOrder().click();
	    }
	    
	    @Then("^user should get confirm oder message and back to home$")
	    public void user_should_get_confirm_oder_message_and_back_to_home() throws Throwable {
	    	exi.BackToHome().click();
	    	
	    }

	   
	   /* @And("^user click on signout$")
	    public void user_click_on_signout() throws Throwable {
	       exi.SignOut().click();
	    }*/

     //***************************************Retrieve password***************************************************//
	    @Given("^Enter signurl in browser$")
	    public void enter_signurl_in_browser() throws Throwable {
	      
	    }
	    @And("^click on signin$")
	    public void click_on_signin() throws Throwable {
	       retpwd.LoginRtv().click();
	    }

	    @When("^user click on forgot your password$")
	    public void user_click_on_forgot_your_password() throws Throwable {
	       retpwd.Forgotpwd().click();
	    }

	    @Then("^conformation msg should be displayed to user and go back to login$")
	    public void conformation_msg_should_be_displayed_to_user_and_go_back_to_login() throws Throwable {
	       retpwd.BackHome().click();
	    }

	    @And("^user enter email address$")
	    public void user_enter_email_address() throws Throwable {
	       retpwd.EmailRvt().sendKeys("swa@gmail.com");
	    }

	    @And("^click on retrive password$")
	    public void click_on_retrive_password() throws Throwable {
	       retpwd.RetrieveBtn().click();
	    }
	    //**************************************NewCustomer********************************************************//
	    


	    @Given("^Enter signurl inbrowser$")
	    public void enter_signurl_inbrowser() throws Throwable {
	       
	    }

	    @And("^click on signin for newregister$")
	    public void click_on_signin_for_newregister() throws Throwable {
	    	reg.LoginNew().click();
	    }


		    @When("^user enter valid email$")
		    public void user_enter_valid_email() throws Throwable {
		    	reg.Email().sendKeys("q-e1-zwq@gmail.com");
		    	Thread.sleep(1000);
		    }
		    @Then("^user clicks create account button$")
		    public void user_clicks_create_account_button() throws Throwable {
		    	reg.Submit().click();
		    	Thread.sleep(1000);
		    }
		    
		    
		    @And("^user selects gender$")
		    public void user_selects_gender() throws Throwable {
		       reg.Female().click();
		       Thread.sleep(1000);
		    }

		    @And("^user enters firstname$")
		    public void user_enters_firstname() throws Throwable {
		       reg.Fname().sendKeys("sai");
		       Thread.sleep(1000);
		    }
		    @And("^user enters lastname$")
		    public void user_enters_lastname() throws Throwable {
		       reg.Lname().sendKeys("kiran");
		       Thread.sleep(1000);
		    }

		    @And("^user enters password$")
		    public void user_enters_password() throws Throwable {
		       reg.Pwd().sendKeys("abc123");
		       Thread.sleep(1000);
		    }
		    
		    @And("^user selects day$")
		    public void user_selects_day() throws Throwable {
		       reg.Day().click();
		       Select sal=new Select(reg.Day());
		       sal.selectByValue("16");
		       Thread.sleep(1000);
		    }
		    @And("^user selects month$")
		    public void user_selects_month() throws Throwable {
		    	reg.Month().click();
			       Select sal1=new Select(reg.Month());
			       sal1.selectByValue("6");
			       Thread.sleep(1000);
		    }

		    @And("^user selects year$")
		    public void user_selects_year() throws Throwable {
		    	reg.Year().click();
			       Select sal2=new Select(reg.Year());
			       sal2.selectByValue("1997");
			       Thread.sleep(1000);
		    }

		    @And("^user selects company$")
		    public void user_selects_company() throws Throwable {
		       reg.Company().sendKeys("CAPGEMINI");
		    }

		    @And("^user selects address$")
		    public void user_selects_address() throws Throwable {
		       reg.Address().sendKeys("gowli");
		       Thread.sleep(1000);
		    }
		    

		    @And("^user enters address2$")
		    public void user_enters_address2() throws Throwable {
		       reg.Address2().sendKeys("financial");  
		      Thread.sleep(1000);
		    }
		    @And("^user enters city$")
		    public void user_enters_city() throws Throwable {
		        reg.City().sendKeys("HYDERABAD");
		        Thread.sleep(1000);
		    }

		    @And("^user selects state$")
		    public void user_selects_state() throws Throwable {
		        reg.State().click();
		        Select sal3=new Select(reg.State());
			       sal3.selectByValue("2");
			       Thread.sleep(1000);
		        
		    }

		    @And("^user enters zipcode$")
		    public void user_enters_zipcode() throws Throwable {
		        reg.Code().sendKeys("12335");
		        Thread.sleep(1000);
		    }

		    @And("^user selects country$")
		    public void user_selects_country() throws Throwable {
		       // reg.Country().sendKeys("United States");
		    	reg.Country().click();
		    	Select sal4=new Select(reg.Country());
		    	sal4.selectByValue("21");
		        Thread.sleep(1000);
		    }

		    @And("^user enters information$")
		    public void user_enters_information() throws Throwable {
		        reg.Other().sendKeys("order");
		        Thread.sleep(1000);
		    }
		    @And("^user enters homephone$")
		    public void user_enters_homephone() throws Throwable {
		       reg.Phone().sendKeys("987654321");
		        Thread.sleep(1000);
		    }

		    @And("^user enters mobile phone$")
		    public void user_enters_mobile_phone() throws Throwable {
		      reg.Mobile().sendKeys("9087654321"); 
		       Thread.sleep(1000);
		    }

		    @And("^user enters future reference$")
		    public void user_enters_future_reference() throws Throwable {
		       reg.Alias().sendKeys(" tel");
		        Thread.sleep(1000);
		    }
		    
		    @Then("^user clicks the register button$")
		    public void user_clicks_the_register_button() throws Throwable {
		       reg.Registerbtn().click();
		        Thread.sleep(1000);
		    }
//****************************************alerts********************************************//
		    @Given("^url in browser$")
		    public void url_in_browser() throws Throwable {
		       
		    }

		    @When("^user click on signin for error msg$")
		    public void user_click_on_signin_for_error_msg() throws Throwable {
		    	al.SubmitErr().click();
		    }

		    @Then("^click on exis signin$")
		    public void click_on_exis_signin() throws Throwable {
		    	al.SubmitAgain().click();
		    }

		    @And("^click on sign$")
		    public void click_on_sign() throws Throwable {
		    	al.LoginErr().click();
		    }

		    @And("^enter email$")
		    public void enter_email() throws Throwable {
		    	al.EmailErr().sendKeys("sai@gmail.com");
		    }

		    @And("^enter password$")
		    public void enter_password() throws Throwable {
		    	al.PasswordErr().sendKeys("sai1234");
		    }
		    //**************************************individual alerts******************************//

		    @Given("^url in firefox$")
		    public void url_in_firefox() throws Throwable {
		      
		    }

		    @When("^enter valid email$")
		    public void enter_valid_email() throws Throwable {
		    	al.EmailErr().sendKeys("swa@gmail.com");
		    }

		    @Then("^alert popup should come$")
		    public void alert_popup_should_come() throws Throwable {
		      Alert promptAlert = driver.switchTo().alert();
		      String expected ="Password is required";
		      String actual = promptAlert.getText();
		      Assert.assertEquals(expected, actual);
		      Thread.sleep(1000);
		      promptAlert.accept();
		    }

		    @And("^click signin$")
		    public void click_signin() throws Throwable {
		    	al.LoginErr().click();
		    }

		    @And("^signin for error$")
		    public void signin_for_error() throws Throwable {
		    	al.SubmitErr().click();
		    }

}
